
  # EXOTIC-FIBER (Code)

  This is a code bundle for EXOTIC-FIBER (Code). The original project is available at https://www.figma.com/design/vEPU3iBAA91szMEbryDlZr/EXOTIC-FIBER--Code-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  